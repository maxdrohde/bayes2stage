## -----------------------------------------------------------------------------
#| include: false
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)


## -----------------------------------------------------------------------------
library(bayes2stage)

set.seed(123)
data <- generate_data(
  N = 1000,                    # 1000 subjects

M = 5,                       # 5 time points each
  x_dist = "normal",           # x is continuous
  beta_x = 1,                  # effect of x on outcome
  beta_t = 2,                  # effect of time
  beta_t_x_interaction = 0.3,  # x modifies the trajectory
  rand_intercept_sd = 3,       # subject-level intercept variation
  rand_slope_sd = 1            # subject-level slope variation
)

head(data)


## -----------------------------------------------------------------------------
stage2_data <- ods_design(
  data,
  sampling_type = "slope",     # select based on OLS slopes
  cutoff_low = 0.25,           # bottom 25% = "low" stratum
  cutoff_high = 0.75,          # top 25% = "high" stratum
  n_sampled = 200,             # sample 200 subjects total
  prop_low = 0.4,              # 40% from low stratum
  prop_middle = 0.2,           # 20% from middle
  prop_high = 0.4              # 40% from high stratum
)

# Check how many have x observed vs missing
table(is.na(stage2_data$x))


## -----------------------------------------------------------------------------
fit <- fit_stan_model(
  data = stage2_data,
  main_model_covariates = c("x", "z", "t"),
  imputation_model_covariates = c("z"),
  imputation_distribution = "normal",
  n_chains = 4,
  iter_warmup = 1000,
  iter_sampling = 1000,
  parallel_chains = 4
)


## -----------------------------------------------------------------------------
# Parameter summaries
fit$summary(variables = c("alpha", "beta_x", "beta_z", "beta_t"))

# Trace plots for diagnostics
mcmc_trace(fit)


## -----------------------------------------------------------------------------
acml_fit <- fit_acml_ods(
  ods_df = stage2_data,
  cutoff_low = 0.25,
  cutoff_high = 0.75
)

acml_fit

